<!DOCTYPE html>
<html lang="en">
<center>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<form action= "cal_62060216357.php" medthod="get">


<lable for ="" > fruit : </lable>
<select name="fruit" required> 

<option value ="">กรุณาเลือก</option>
<option value ="mango">Mango</option>
<option value ="grape">Grape</option>
<option value ="orange">orange</option>

</select>

<input type="radio" name="operator2" value="1"> 1 KG
  <input type="radio" name="operator2" value="2"> 2 KG
  <input type="radio" name="operator2" value="3"> 3 KG
 <br> <br>

มะม่วง กิโลละ 100 บาท <br>
องุ่น กิโลละ 200 บาท   <br>
ส้ม กิโลละ 300 บาท    <br>

<br><br><br><br>

Width : <input type = "number" min ="100" max="500" name ="width" required/> <br>



<input type ="submit" value ="ตรวจรางวัล " name ="submit">

   


</body>

</center>

</html>